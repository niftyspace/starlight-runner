
var gameChar_x;
var gameChar_y;
var floorPos_y;
var isLeft = false;
var isRight = false;
var isFalling = false;
var isPlummeting = false;
var spaceships_x;
var stars_x;
var planets_x;
var starPos_y;
var planetPos_y;
var cameraPosX;
var collectables;
var spaceshipPos_y;
var starPositions = [];
var jumpCount = 0;
var maxJumps = 1000;
var enemies;
var platforms;
var gameScore = 0;
var lives = 3;
var flagpole;
var gameActive = true;
var showInstructions = true;
var instructionStartTime;
var gameStartTime;
var gameTimeLimit = 120000; 
var flagpoleVisible = false;

function preload() {
    
    jumpSound = loadSound('386639__jalastram__sfx_jump_50.wav');
    collectSound = loadSound('135936__bradwesson__collectcoin.wav'); 
    victorySound = loadSound('717771__1bob__victory-chime.wav');
    canyonFallSound = loadSound('395443__plasterbrain__cartoon-fall.wav');
    canyonFallSound.setVolume(0.5); 
}

var showInstructions = true; 
var instructionStartTime;

function setup() {
    createCanvas(1024, 576);
    floorPos_y = height * 3 / 4;
    gameChar_x = width / 4;
    gameChar_y = floorPos_y;
    spaceshipPos_y = floorPos_y - 200;
    starPos_y = floorPos_y - 350;
    planetPos_y = floorPos_y -100;
    spaceships_x = [-50, 600, 1200, 1800,2400,3000,3600,4200,4800,5400,6000,6600,7200,7800,8400,9000,9600,10200,10800];
    stars_x = [-600, 100, 750, 1350,1950, 2550, 3150, 3750, 4350, 4950, 5550, 6150, 6750, 7350, 7950, 8550, 9150, 9750, 10350];
    planets_x = [-300, 350, 1000, 1600, 2200, 2800, 3400, 4000, 4600, 5200, 5800, 6400, 7000, 7600, 8200, 8800, 9400, 10600];

    collectables = [
        {x_pos: 360, y_pos: floorPos_y-150, size: 30, isFound: false},
        {x_pos: 250, y_pos: floorPos_y-240, size: 30, isFound: false},
        {x_pos: 140, y_pos: floorPos_y-150, size: 30, isFound: false},
        {x_pos: 25, y_pos: floorPos_y-150, size: 30, isFound: false},
        {x_pos: -90, y_pos: floorPos_y-15, size: 30, isFound: false},
        {x_pos: -430, y_pos: floorPos_y-140, size: 30, isFound: false},
        {x_pos: -500, y_pos: floorPos_y-240, size: 30, isFound: false},
        {x_pos: -590, y_pos: floorPos_y-340, size: 30, isFound: false},
        {x_pos: -760, y_pos: floorPos_y-240, size: 30, isFound: false},
        {x_pos: -830, y_pos: floorPos_y-140, size: 30, isFound: false},
        {x_pos: 750, y_pos: floorPos_y-120, size: 30, isFound: false},
        {x_pos: 900, y_pos: floorPos_y-180, size: 30, isFound: false},
        {x_pos: 1200, y_pos: floorPos_y-220, size: 30, isFound: false},
        {x_pos: 1700, y_pos: floorPos_y-15, size: 30, isFound: false},
        {x_pos: 1800, y_pos: floorPos_y-15, size: 30, isFound: false},
        {x_pos: 2150, y_pos: floorPos_y-140, size: 30, isFound: false},
        {x_pos: 2290, y_pos: floorPos_y-180, size: 30, isFound: false},
        {x_pos: 2480, y_pos: floorPos_y-200, size: 30, isFound: false},
        {x_pos: 2640, y_pos: floorPos_y-220, size: 30, isFound: false},
        {x_pos: 2759, y_pos: floorPos_y-220, size: 30, isFound: false},
        {x_pos: 2890, y_pos: floorPos_y-220, size: 30, isFound: false},
        {x_pos: 3340, y_pos: floorPos_y-160, size: 30, isFound: false},
        {x_pos: 3650, y_pos: floorPos_y-15, size: 30, isFound: false},
        {x_pos: 3950, y_pos: floorPos_y-120, size: 30, isFound: false},
        {x_pos: 4400, y_pos: floorPos_y-220, size: 30, isFound: false},
        {x_pos: 4600, y_pos: floorPos_y-220, size: 30, isFound: false},
    
    ];

    canyons = [
        {x_pos: 180, width: 140},
        {x_pos: 700, width: 100},
        {x_pos: -300, width: 120},
        {x_pos: -690, width: 110},
        {x_pos: 1500, width: 90},
        {x_pos: 1900, width: 90},
        {x_pos: 2600, width: 400},
        {x_pos: 3900, width: 90},
        {x_pos: 7800, width: 90},
        {x_pos: 9200, width: 90},
    ];

    enemies = [];
    enemies.push(new enemy(970, floorPos_y-10,250));
    enemies.push(new enemy(-50, floorPos_y-10,50));
    enemies.push(new enemy(-690, floorPos_y-330,50));   
    enemies.push(new enemy(3200, floorPos_y-15,50));
    enemies.push(new enemy(3500, floorPos_y-15,50));
    enemies.push(new enemy(4500, floorPos_y-15,200));
    enemies.push(new enemy(1050, floorPos_y-200,200));
    enemies.push(new enemy(4200, floorPos_y-230,50));

    
    lives = 3; 
    flagpole = { x_pos: 5000, isReached: false };

    
    platforms = [];
    platforms.push(createPlatform(700, floorPos_y - 70, 100));
    platforms.push(createPlatform(310, floorPos_y - 100, 100));
    platforms.push(createPlatform(200, floorPos_y - 190, 100));
    platforms.push(createPlatform(90, floorPos_y - 100, 100));
    platforms.push(createPlatform(5, floorPos_y - 100, 100));
    platforms.push(createPlatform(-480, floorPos_y - 100, 100));
    platforms.push(createPlatform(-540, floorPos_y - 200, 100));
    platforms.push(createPlatform(-620, floorPos_y - 300, 100));
    platforms.push(createPlatform(-690, floorPos_y - 300, 100)); 
    platforms.push(createPlatform(-760, floorPos_y - 300, 100));
    platforms.push(createPlatform(-820, floorPos_y - 200, 100));
    platforms.push(createPlatform(-880, floorPos_y - 100, 100));
    platforms.push(createPlatform(1030, floorPos_y - 180, 100));
    platforms.push(createPlatform(1110, floorPos_y - 180, 100));
    platforms.push(createPlatform(1190, floorPos_y - 180, 100));
    platforms.push(createPlatform(850, floorPos_y - 130, 100));
    platforms.push(createPlatform(2100, floorPos_y - 80, 100));
    platforms.push(createPlatform(2250, floorPos_y - 140, 100));
    platforms.push(createPlatform(2430, floorPos_y - 150, 100));
    platforms.push(createPlatform(2600, floorPos_y - 180, 100));
    platforms.push(createPlatform(2700, floorPos_y - 180, 100));
    platforms.push(createPlatform(2800, floorPos_y - 180, 100));
    platforms.push(createPlatform(2900, floorPos_y - 180, 100));
    platforms.push(createPlatform(3100, floorPos_y - 120, 100));
    platforms.push(createPlatform(4100, floorPos_y - 100, 100));
    platforms.push(createPlatform(4200, floorPos_y - 190, 100));
    platforms.push(createPlatform(4300, floorPos_y - 190, 100));
    platforms.push(createPlatform(4400, floorPos_y - 190, 100)); 
    platforms.push(createPlatform(4500, floorPos_y - 190, 100));
    platforms.push(createPlatform(4600, floorPos_y - 190, 100));
    platforms.push(createPlatform(4700, floorPos_y - 190, 100));

    for (let i = 0; i < 200; i++) {
        starPositions.push({
            x: random(width),
            y: random(height),
            size: random(1, 3),
            brightness: random(100, 255)
        });
    }
    instructionStartTime = millis(); 
    startGame();
}

function startGame() {

    gameChar_x = width / 2;
    gameChar_y = floorPos_y;
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    gameActive = true; 
}

function draw() {
    cameraPosX = gameChar_x - width / 2;

    drawGradientBackground();
    drawBackgroundStars();
    
    // Floor
    noStroke();
    fill(166,19,157);
    rect(-width, floorPos_y, width * 3, height - floorPos_y);
    fill(52,21,107); 
    let blueRectWidth = width * 1.5; 
    let blueRectHeight = (height - floorPos_y) * 0.9;
    let blueRectX = -width / 2; 
    let blueRectY = floorPos_y + (height - floorPos_y) * 0.15; 
    rect(blueRectX, blueRectY, blueRectWidth, blueRectHeight);

    if (allCollectablesFound()) {
        flagpoleVisible = true;
    }

    if (showInstructions) {

        let textColor = color(255, 255, 255);
        let highlightColor = color(0, 255, 255); 
        textSize(32);
        textAlign(CENTER);
        fill(textColor);
        text("Use 'A' to move left, 'D' to move right, 'W' to jump.", width / 2, height / 2)-40;
        fill(textColor);
        text("Collect all items to reach the flag!", width / 2, height / 2 + 40);
        fill(highlightColor);
        text("(hint: A step in the right direction might lead to victory!)", width / 2, height / 2 +80);

        if (millis() - instructionStartTime > 5000) { 
            showInstructions = false; 
        }
        return; 
    }

    push();
    translate(-cameraPosX, 0);

    drawplanet();
    drawstars();
    drawspaceship();

    
    for (var i = 0; i < platforms.length; i++) {
        platforms[i].draw();
    }

    for (var i = 0; i < canyons.length; i++) {
        drawCanyon(canyons[i]);
        checkCanyon(canyons[i]);
    }

    for (var i = 0; i < collectables.length; i++) {
        drawCollectable(collectables[i]);
        checkCollectable(collectables[i]);
    }


    if (flagpoleVisible) {
        drawFlagpole();
    }

    drawCharacter();

    for (let enemy of enemies) {
        enemy.draw();
        if (enemy.checkContact(gameChar_x, gameChar_y)) {
          if (lives > 0) {
            lives--;
            startGame();
          }
        }
    }

    checkPlayerDie();

    if (flagpoleVisible) {
        checkFlagpole();
    }

    if (lives < 1) {
        fill(255);
        textSize(70);
        text("Game Over", width / 2 , height / 2);
        gameActive = false; 
    }

    if (flagpole.isReached) {
        fill(255);
        textSize(70);
        text("Level Complete", width / 2 - 150, height / 2);
        gameActive = false; 
    }

   // Movement logic
   if (gameActive) {
    if (isLeft && !isPlummeting) {
        gameChar_x -= 4; // Move left
    }
    if (isRight && !isPlummeting) {
        gameChar_x +=4; // Move right
    }

    // Gravity effect
    if (gameChar_y < floorPos_y || isPlummeting) {
        let isContact = false;
        for (let platform of platforms) {
          if (platform.checkContact(gameChar_x, gameChar_y)) {
            isContact = true;
            gameChar_y = platform.y - 10;
            break;
          }
        }

        if (isContact == false) {
            gameChar_y += 4; 
            isFalling = true;
        } else {
            isFalling = false;
            jumpCount = 0; 
        }
    } else {
        isFalling = false; 
    }

    // Canyon interaction
    for (var i = 0; i < canyons.length; i++) {
        if (
            gameChar_x > canyons[i].x_pos &&
            gameChar_x < canyons[i].x_pos + canyons[i].width &&
            gameChar_y >= floorPos_y
        ) {
            isPlummeting = true; 
        }
    }

    if (isPlummeting) {
        gameChar_y += 5; 
    }

    for (var i = 0; i < enemies.length; i++){
        enemies[i].draw();

        var isContact = enemies[i].checkContact(gameChar_x, gameChar_y);
        if (isContact){
            if (lives>0){
                startGame();
                break;
            }
        }
    }
    pop();

    fill(255);
    textSize(24);
    text("Score: " + gameScore + "/" + collectables.length, 60, 30);

   
    // Draw lives
    for (var i = 0; i < lives; i++) {
        fill(255, 0, 0);
        ellipse(20 + i * 30, 50, 20, 20);
    }
   }
}

function drawCharacter() {
    if (isLeft && isFalling) {
        drawAstronautSide(gameChar_x, gameChar_y - 20, frameCount, "left");
    } else if (isRight && isFalling) {
        drawAstronautSide(gameChar_x, gameChar_y - 20, frameCount, "right");
    } else if (isLeft) {
        drawAstronautSide(gameChar_x, gameChar_y, frameCount, "left");
    } else if (isRight) {
        drawAstronautSide(gameChar_x, gameChar_y, frameCount, "right");
    } else if (isFalling || isPlummeting) {
        drawAstronautFront(gameChar_x, gameChar_y - 20, frameCount);
    } else {
        drawAstronautFront(gameChar_x, gameChar_y, frameCount);
    }
}

function drawFlagpole() {
    fill(255);
    if (!flagpole.isReached) {
        fill(987,145,395);
        rect(flagpole.x_pos, floorPos_y-240, 60,40)
        rect(flagpole.x_pos, floorPos_y-200, 10, 200);

        if (victorySound) {
            victorySound.play();
        }

    } else {
        fill(0, 255, 0);
        rect(flagpole.x_pos, floorPos_y-240, 60,40)
        rect(flagpole.x_pos, floorPos_y-200, 10, 200);
    }
}

function allCollectablesFound() {
    return collectables.every(collectable => collectable.isFound);
}

function checkFlagpole() {
    if (!flagpole.isReached && gameChar_x > flagpole.x_pos - 20 && gameChar_x < flagpole.x_pos + 20 && gameChar_y >= floorPos_y - 50) {
        flagpole.isReached = true;
    }
}

function checkPlayerDie() {
    if (gameChar_y > height) { 
        lives--; 
        if (lives > 0) {
            startGame();
        } else {
            noLoop();
        }
    }
}

function keyPressed() {
    if (gameActive) {
        if (key === 'a') {
            isLeft = true;
        }
        if (key === 'd') {
            isRight = true;
        }
        if (key === 'w') {
            if (jumpCount < maxJumps) {
                gameChar_y -= 140;
                isFalling = true;
                jumpCount++;

                
                if (jumpSound) {
                    jumpSound.play();
                }
            }
        }
    }
}


function keyReleased() {
    if (key === 'a') {
        isLeft = false;
    }
    if (key === 'd') {
        isRight = false;
    }
}

function drawAstronautFront(x, y) {
    fill(255);
    ellipse(x, y - 50, 30, 30); // Helmet
    fill(0);
    ellipse(x, y - 50, 24, 24); // Visor
    fill(255);
    rect(x - 10, y - 42, 20, 30); // Body
    fill(255);
    ellipse(x+5,y-47,3,3); // helmet design
    fill(255);
    ellipse(x+5,y-54,5,6); // helmet design

    fill(255);
    rect(x - 10, y - 16, 8, 15, 4); // Left leg
    rect(x + 2, y - 16, 8, 15, 4); // Right leg

    rect(x + 8, y - 34, 8, 8, 4); // Left hand
    rect(x - 16, y - 34, 8, 8, 4); // Right hand

    fill(255,0,0);
    rect(x-10,y-24,20,6); //belt red part

    fill(0,0,255);
    ellipse(x,y-21,6,8); //belt blue part

}

function drawAstronautSide(x, y, frameCount) {
    fill(255);
    ellipse(x, y - 50, 30, 30); // Helmet
    fill(0);
    ellipse(x, y - 50, 24, 24); // Visor

    fill(255);
    rect(x - 10, y - 42, 20, 30, 5); // Body

    fill(255);
    ellipse(x+5,y-47,3,3); // helmet design
    fill(255);
    ellipse(x+5,y-54,5,6); // helmet design

    fill(255);
    // Animating legs
    let legOffset = sin(frameCount * 0.2) * 2; 
    rect(x - 10 + legOffset, y - 20, 8, 22, 4); // Left leg
    rect(x + 2 - legOffset, y - 20, 8, 22, 4); // Right leg
    
    // Animating arms
    let armOffset = cos(frameCount * 0.2) * 2;
    rect(x + 8 - armOffset, y - 34, 8, 8, 4); // Left arm
    rect(x - 16 + armOffset, y - 34, 8, 8, 4); // Right arm

  
    fill(255,0,0);
    rect(x-10,y-24,20,5); //belt red part
    fill(0,0,255);
    ellipse(x,y-21,6,8); //belt blue part
    
}

function drawstars() {
    for (var i = 0; i < stars_x.length; i++) {
        
        fill(114,127,152);
        triangle(
            stars_x[i],
            starPos_y - 60,
            stars_x[i] - 50,
            starPos_y,
            stars_x[i] + 50,
            starPos_y
        );
        triangle(
            stars_x[i],
            starPos_y + 60,
            stars_x[i] - 50,
            starPos_y,
            stars_x[i] + 50,
            starPos_y
        );

        // Inner triangles
        fill(137,149,171);
        triangle(
            stars_x[i],
            starPos_y - 45,
            stars_x[i] - 35,
            starPos_y,
            stars_x[i] + 35,
            starPos_y
        );
        triangle(
            stars_x[i],
            starPos_y + 45,
            stars_x[i] - 35,
            starPos_y,
            stars_x[i] + 35,
            starPos_y
        );
        let miniOffset = 100;
        // Outer triangles
        fill(114,127,152);
        triangle(
            stars_x[i] + miniOffset,
            starPos_y - 30,
            stars_x[i] + miniOffset - 25,
            starPos_y,
            stars_x[i] + miniOffset + 25,
            starPos_y
        );
        triangle(
            stars_x[i] + miniOffset,
            starPos_y + 30,
            stars_x[i] + miniOffset - 25,
            starPos_y,
            stars_x[i] + miniOffset + 25,
            starPos_y
        );

        // Inner triangles
        fill(137,149,171);
        triangle(
            stars_x[i] + miniOffset,
            starPos_y - 22,
            stars_x[i] + miniOffset - 18,
            starPos_y,
            stars_x[i] + miniOffset + 18,
            starPos_y
        );
        triangle(
            stars_x[i] + miniOffset,
            starPos_y + 22,
            stars_x[i] + miniOffset - 18,
            starPos_y,
            stars_x[i] + miniOffset + 18,
            starPos_y
        );
        
    }
    
}

function drawspaceship() {
    for (var i = 0; i < spaceships_x.length; i++) {
        
        push();

        translate(spaceships_x[i], spaceshipPos_y);

        scale(0.7);
        rotate(0.5);

        fill(229,160,160); 
        ellipse(0, 0, 50, 150);

        fill(171,18,18); 
        triangle(
            -60, 0,
            -23, 30,
            -23, -30
        );

        
        triangle(
            60, 0,
            23, -30,
            23, 30
        );

        
        fill(50,126,192); 
        stroke(14,78,135);
        strokeWeight(2); 
        ellipse(0, -45, 20, 20);
        

       
        noStroke();
        drawFire(0, 75); 

      
        pop();
    }
}

function drawFire(x, y) {
    
    fill(255, 69, 0); 
    beginShape();
    vertex(x - 15, y);
    bezierVertex(x - 20, y + 45, x + 20, y + 45, x + 15, y);
    bezierVertex(x + 10, y + 30, x - 10, y + 30, x - 15, y);
    endShape();

    
    fill(255, 215, 0);
    beginShape();
    vertex(x - 10, y + 20);
    bezierVertex(x - 15, y + 40, x + 15, y + 40, x + 10, y + 20);
    bezierVertex(x + 5, y + 35, x - 5, y + 35, x - 10, y + 20);
    endShape();
}

function drawplanet() {
    for (var i = 0; i < planets_x.length; i++) {
        push();

        translate(planets_x[i], planetPos_y);

        rotate(-0.3);

        fill(0, 0, 139);
        noStroke();
        ellipse(0, 0, 140); 
        stroke(0, 255, 255);
        strokeWeight(5);
        noFill();
        arc(0, 10, 180, 80, PI / 1.15, (10.65 * PI) / 5); 
        
        pop();
    }
}



function drawCollectable(t_collectable) {
    if (!t_collectable.isFound) {
        fill(184, 134, 11);
        noStroke();
        ellipse(t_collectable.x_pos, t_collectable.y_pos, t_collectable.size);
        fill(255, 215, 0);
        triangle(
            t_collectable.x_pos,
            t_collectable.y_pos - 15,
            t_collectable.x_pos - 13,
            t_collectable.y_pos + 8,
            t_collectable.x_pos + 13,
            t_collectable.y_pos + 8
        );
        triangle(
            t_collectable.x_pos,
            t_collectable.y_pos + 16,
            t_collectable.x_pos - 13,
            t_collectable.y_pos - 8,
            t_collectable.x_pos + 14,
            t_collectable.y_pos - 8
        );
    }
}

function drawCanyon(t_canyon) {
   
    fill(0,0,0);
    rect(t_canyon.x_pos, floorPos_y, t_canyon.width, height - floorPos_y);
}

function checkCollectable(t_collectable) {
    if (
        !t_collectable.isFound &&
        gameChar_y >= t_collectable.y_pos - t_collectable.size && 
        gameChar_y <= t_collectable.y_pos + t_collectable.size + 50 && 
        abs(gameChar_x - t_collectable.x_pos) < t_collectable.size 
    ) {
        t_collectable.isFound = true;
        gameScore++;

        if (collectSound) {
            collectSound.play();
        }
    }
}

function checkCanyon(t_canyon) {
    
    const charWidth = 20;

   
    if (
        gameChar_y >= floorPos_y && 
        gameChar_x + charWidth / 2 > t_canyon.x_pos && 
        gameChar_x - charWidth / 2 < t_canyon.x_pos + t_canyon.width 
    ) {
        isPlummeting = true;
        
        if (canyonFallSound) {
            canyonFallSound.play();
        }
    }
}

function createPlatform(x, y, length) {
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function() { 

            fill(150, 150, 150);
            noStroke();
            ellipse(this.x, this.y, 25, 30);
            ellipse(this.x + 15, this.y, 30, 30);
            ellipse(this.x + 30, this.y, 35, 30);
            ellipse(this.x + 50, this.y, 40, 40);
            ellipse(this.x + 70, this.y, 30, 30);
            ellipse(this.x + 85, this.y, 30, 30);
            ellipse(this.x + 100, this.y, 35, 30);
    
            fill(90, 90, 90);
            ellipse(this.x + 10, this.y + 5, 12, 8);
            ellipse(this.x + 40, this.y - 7, 14, 9);
            ellipse(this.x + 70, this.y + 4, 10, 7);
            ellipse(this.x + 85, this.y - 8, 16, 11);
            ellipse(this.x + 20, this.y - 5, 8, 6);
            
           
            fill(170, 170, 170);
            ellipse(this.x + 15, this.y - 8, 8, 5);
            ellipse(this.x + 50, this.y + 6, 12, 7);
            ellipse(this.x + 80, this.y - 5, 9, 6);

        },
        checkContact: function(gc_x, gc_y) {
           
            var isWithinXBounds = gc_x +15> this.x && gc_x -15< this.x + this.length;
        
            
            var isFallingOntoPlatform = gc_y + 50 >= this.y && gc_y <= this.y + 10; 
        
            
            if (isWithinXBounds && isFallingOntoPlatform) {
                return true;
            }
            return false;
        }
    };
    return p;
}

function enemy (x,y,range){
    this.x = x;
    this.y = y;
    this.range = range;

    this.currentX = x;
    this.inc = 1;

    this.update = function(){
        this.currentX += this.inc;

        if(this.currentX >= this.x + this.range){
            this.inc = -1;
        }
        else if (this.currentX < this.x){
            this.inc = 1;
        }
    }

    this.draw = function(){
        this.update();

        fill(33, 212, 57);
        
        ellipse(this.currentX, this.y - 5, 25, 30);

        noStroke();
        triangle(this.currentX - 12, this.y,
                this.currentX + 12, this.y,
                this.currentX, this.y + 15); 
        
        fill(25, 20, 50);
        noStroke();
        ellipse(this.currentX - 6, this.y - 6, 7, 13);
        ellipse(this.currentX + 6, this.y - 6, 7, 13);
        
        fill(255);
        noStroke();
        ellipse(this.currentX - 6, this.y-2 - 6, 1, 5);
        ellipse(this.currentX + 6, this.y-2 - 6, 1, 5);
    
    }


    this.checkContact = function(gc_x,gc_y){
        var d = dist(gc_x, gc_y, this.currentX, this.y)
        if (d<20){
            return true;
        }
        return false;
    }
}

function drawGradientBackground() {
    let centerX = width / 2;
    let centerY = height / 2;
    let maxRadius = dist(0, 0, centerX, centerY); 

    let darkPurple = color(8,23,54);  
    let lightPurple = color(12,39,92);

    for (let r = maxRadius; r > 0; r -= 2) {
        let inter = map(r, 0, maxRadius, 0, 1);
        let gradientColor = lerpColor(lightPurple, darkPurple, inter);
        fill(gradientColor);
        noStroke();
        ellipse(centerX, centerY, r * 2, r * 2);
    }
}
function drawBackgroundStars() {
    noStroke();
    for (let star of starPositions) {
        star.brightness = random(100, 255);
        fill(star.brightness);
        ellipse(star.x, star.y, star.size, star.size); 
    }
}

function allCollectablesFound() {
    return collectables.every(collectable => collectable.isFound);
}
